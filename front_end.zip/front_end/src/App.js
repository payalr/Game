
import React, { useEffect } from 'react';
import MyContextProvider from './contexts/MyContext';
import Home from './containers/Home'

/*function App() {

    return (
      <MyContextProvider>
          <Home/>
      </MyContextProvider>
    );
}*/

const App = () => {

    useEffect(() => {
        window.oncontextmenu = function (event) {
            event.preventDefault();
            event.stopPropagation();
            return false
        }

        return () => { }
    }, [])

    return (
      <MyContextProvider>
          <Home/>
      </MyContextProvider>
    );
}


export default App;

/*import React, { useEffect } from 'react';
import Home from './containers/Home';

const App = () => {

  useEffect(() => {
      window.oncontextmenu = function (event) {
      event.preventDefault();
      event.stopPropagation();
      return false
    }

    return () => { }
    }, [])

  return (
    <Home />
  );
}

export default App;*/