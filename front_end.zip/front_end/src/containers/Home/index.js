﻿import React, { Component , useContext, useState , PropTypes } from 'react'
import {useHistory , withRouter , Link,BrowserRouter as Router,Switch,Route,useLocation,Redirect} from 'react-router-dom';
import {MyContext} from '../../contexts/MyContext'
// Importing the Login & Register Componet
import BattleArena from '../BattleArena';
import Menu from './Menu'
import CharacterSelect from '../CharacterSelect'
import Layout from '../../Layout'
import Login from './Login';
import Register from './Register';
import Game from './game';



function Home(){

    const {rootState,logoutUser,togglenav1} = useContext(MyContext);
    console.log(rootState);
    const {isAuth,theUser,showLogin} = rootState;
    let history = useHistory();

    // If user Logged in
    if(isAuth)
    {
        return <Game/>;
      /* return(
          <div className="_loginRegister">
        <div className="form-control" >
          WelCome ! {theUser}
        </div>
      <div></div>
<div className="form-control">
  <button type="submit" onclick="tog">Game</button>
</div>
<div className="form-control">
  <button type="submit">History</button>
</div>
<div className="form-control">
  <button type="submit" onClick={logoutUser}>Logout</button>
</div>

         </div>
  )*/
    }
    // Showing Login Or Register Page According to the condition
    else if(showLogin){
       // history.push("/");
        return <Login/>;
    }
    else{
        //  return <Register/>;
        return <Register/>;
      //  <NavButton to="/CharacterSelect">Choose a character</NavButton>
    }
    
}

export default Home ;