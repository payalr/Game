﻿import React, { Component , useContext, useState , PropTypes } from 'react'
import { useHistory , withRouter , Link,BrowserRouter as Router,Switch,Route} from 'react-router-dom';
import {MyContext} from '../../contexts/MyContext'
// Importing the Login & Register Componet
import BattleArena from '../BattleArena';
import Menu from './Menu'
import CharacterSelect from '../CharacterSelect'
import Layout from '../../Layout'
import Login from './Login';



const Game = () => {
    const {rootState,logoutUser,togglenav} = useContext(MyContext);
    
    const {isAuth,theUser,showLogin} = rootState;
    console.log(togglenav);
    if(isAuth){
        return (
                   <Router>
             <div><Link to="/"><button type="submit" onClick={togglenav}>Home</button></Link>   <button type="submit" onClick={logoutUser}>Logout</button></div>
                <Layout>
                    <Switch>{theUser}
                        <Route exact path="/" component={Menu} />
                        <Route path="/characterSelect" component={CharacterSelect} />
                    
                        <Route path="/battle" component={BattleArena} />
                    </Switch>
                </Layout>
            </Router>
    );
}else{
    return <Login/>;
}
}

export default Game;