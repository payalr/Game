import React, {useContext, useState} from 'react'
import { useHistory } from 'react-router-dom';
import {MyContext} from '../../contexts/MyContext'
import BattleArena from '../BattleArena';
import Menu from './Menu'
import CharacterSelect from '../CharacterSelect'
import Layout from '../../Layout'
import Logout from './Register';
import Game from './game';
import History from './game';

function Dashboard(){
    
   
    

  
return(
    <div className="_loginRegister">
        <div className="form-control">
    <button type="submit">Game</button>
</div>
    <div className="form-control">
    <button type="submit">History</button>
</div>
    <div className="form-control">
    <button type="submit">Logout</button>
</div>

</div>
    );

 }
export default Dashboard;