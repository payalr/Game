const predefinedCharacters = [
    {
        name: localStorage.getItem('username'),
        gender: localStorage.getItem('userid'),
        className: "warrior",
        avatar: "MALE1",
        lvl: 4,
        hp: 90,
        maxHp: 90,
        ap: 9,
        maxAp: 9,
        attributes: {
            str: 11,
            dex: 11,
            int: 2,
            wis: 6,
            ten: 7,
            luc: 3,
        },
        stats: {
            criticalMod: 1.6,
            criticalChance: 16,
            chanceToMiss: 29,
        },
        defense: {
            physical: 6,
            magic: 12,
            poison: 14,
            bleeding: 6,
        },
        effects: [],
        utilityEffects: [],
        abilities: [
            {
                id: 'ATTACK_DOUBLE_STRIKE',
                type: 'ATTACK',
                damageType: 'PHYSICAL',
                name: 'Attack',
                description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam",
                damageMin: 7,
                damageMax: 10,
                apCost: 9,
                usesPerBattle: Infinity,
            },
            {
                id: 'ATTACK_CYCLONE',
                type: 'ATTACK',
                damageType: 'PHYSICAL',
                name: 'Power Attack',
                description: "Lorem ipsum dolor sid tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam",
                damageMin: 4,
                damageMax: 7,
                apCost: 9,
                usesPerBattle: Infinity,
                effects: [
                    { id: "BLEEDING", label: "bleeding", turnsDuration: 2, chance: 50, useValue: 33, use: "ENEMY" },
                ],
            },
            
            {
                id: 'UTILITY_POTION_HEAL',
                type: 'UTILITY',
                name: 'Healing',
                label: "healing",
                description: "You regain health points when you drink this potion.",
                useValue: 40,
                apCost: 9,
                usesPerBattle: 1,
                turnsDuration: 1,
                effects: [
                    { id: "HEALING", label: "healing", turnsDuration: 2, chance: 100, useValue: 20, use: "SELF" }
                ],
            }
            
        ],
        baseStatsCopy: {
            stats: {
                criticalMod: 1.6,
                criticalChance: 16,
                chanceToMiss: 29,
            },
            defense: {
                physical: 6,
                magic: 12,
                poison: 14,
                bleeding: 6,
            },
        }
    }
    
]

export default predefinedCharacters;