export const UTILITY = "UTILITY";
export const ATTACK = "ATTACK";
export const SPEC_ATTACK = "SPEC_ATTACK";
export const SELF = "SELF";
export const ENEMY = "ENEMY";
export const EMPTY = "EMPTY";
