export const POISON = "POISON";
export const BLEEDING = "BLEEDING";
export const LOOSE_NEXT_TURN = "LOOSE_NEXT_TURN";
export const HEALING = "HEALING";
