export const animationsDelay = {
    beforeShowInfo: 500,
    beforeChangeData: 100,
    beforeHideInfo: 6000,
    beforeBattleEndInfo: 800,
}