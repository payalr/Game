import { colors } from './colors';
import { device } from './media';
export const theme = {
    colors,
    device,
}