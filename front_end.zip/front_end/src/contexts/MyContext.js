import React, { createContext,Component } from "react";
import axios from 'axios'
export const MyContext = createContext();

// Define the base URL
const Axios = axios.create({
    baseURL: 'http://localhost:8765/api/',
});
const headers = { 
    'Accept': 'application/json',
    'Content-Type': 'application/json',
};



class MyContextProvider extends Component{

    constructor(){
        super();
   /*    this.state = {
            showLogin:true,
            isAuth:true,
            theUser:"Payal Raghuwanshi",
        }*/
      
       // this.isLoggedIn = this.isLoggedIn.bind(this); 
    }
    componentDidMount(){

        this.isLoggedIn();
    }
       
    // Root State
    state = {
        showLogin:true,
        isAuth:false,
        theUser:null,
        }
    
    // Toggle between Login & Signup page
    toggleNav = () => {
        const showLogin = !this.state.showLogin;
        this.setState({
            ...this.state,
            showLogin
        })
    }
        // Toggle between Login & Signup page
        toggleNav1 = () => {
            const showLogin = !this.state.showLogin;
            this.setState({
                ...this.state,
                showLogin
            })
        }
       

        // On Click the Log out button
        logoutUser = () => {
            localStorage.removeItem('loginToken');
            localStorage.removeItem('userid');
            localStorage.removeItem('username');
            localStorage.removeItem('image');
            localStorage.removeItem('gameid');
            localStorage.removeItem('gameslug');
            this.setState({
                ...this.state,
                    isAuth:false
        })
    }

    registerUser = async (user) => {

        // Sending the user registration request
        const register = await Axios.post('users',{user:{
            username:user.name,
            email:user.email,
            password:user.password }
        },{ headers });

        return register.data;
    }


        loginUser = async (user) => {

            // Sending the user Login request
            const login = await Axios.post('users/login',{ user:{
                email:user.email,
                password:user.password}
            },{ headers });
            console.log(login.data.user);
            return login.data;
        }
       
 
        gameData = async (user,time) => {
            const loginToken = localStorage.getItem('loginToken');
                // Sending the user game request
                const game = await Axios.post('articles',{ article:{
                    title:time,
                    description:"",
                    body:"",
                    tagList:"[Incomplete]"}
                },{
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                        'Authorization':loginToken ,
                        'Access-Control-Allow-Origin':'*'
                    }
                });
            //    console.log('ddddddddddddddddd');
                console.log(game.data);
                return game.data;
        }

        gameUpdate = async (gameidddx,log) => {
            let gameiddd = localStorage.getItem('gameid');
            let loginToken = localStorage.getItem('loginToken');
            let slug = localStorage.getItem('gameslug');
            // Sending the user game request
            let game2 = await Axios.put(`articles/${slug}`,{ article:{
                description:JSON.stringify(log),
               body:""}
            },{
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                    'Authorization':loginToken ,
                    'Access-Control-Allow-Origin':'*'
                }
            });
            //    console.log('ddddddddddddddddd');
            console.log(game2.data);
            return game2.data;
        }
      
        
      
            isLoggedIn =  () => {        
            this.isLoggedIn = this.isLoggedIn.bind(this);
                const loginToken = localStorage.getItem('loginToken');
                //  this.mounted = true; 
                // If inside the local-storage has the JWT token
                if(loginToken){

                    //Adding JWT token to axios default header
                    // Axios.defaults.headers.common['Authorization'] = 'bearer '+loginToken;

                    // Fetching the user information
                    //  const {data} = await Axios.get('');

                    // If user information is successfully received
                    this.setState(state=>{return {
                         ...state,
                            isAuth:true,
                            theUser:localStorage.getItem('username')
                    }
                    });

        
            }
    
    }

    render(){
        const contextValue = {
            rootState:this.state,
            toggleNav:this.toggleNav,
            isLoggedIn:this.isLoggedIn,
            registerUser:this.registerUser,
            loginUser:this.loginUser,
            logoutUser:this.logoutUser,
            gameData:this.gameData,
            gameUpdate:this.gameUpdate
        }
        return(
            <MyContext.Provider value={contextValue}>
    {this.props.children}
</MyContext.Provider>
)
    }

    }

export default MyContextProvider;