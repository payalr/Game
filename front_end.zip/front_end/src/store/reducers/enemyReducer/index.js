import reducerPlayerEnemyPattern from '../reducerPlayerEnemyPattern';


const initialState = null;

const enemyReducer = reducerPlayerEnemyPattern('ENEMY', initialState)

export default enemyReducer;