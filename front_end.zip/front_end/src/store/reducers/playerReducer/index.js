import reducerPlayerEnemyPattern from '../reducerPlayerEnemyPattern';


const initialState = null;

const playerReducer = reducerPlayerEnemyPattern('PLAYER', initialState)

export default playerReducer;