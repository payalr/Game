-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 25, 2021 at 08:57 PM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.4.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `payal`
--

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

DROP TABLE IF EXISTS `articles`;
CREATE TABLE IF NOT EXISTS `articles` (
  `id` char(36) NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `body` text DEFAULT NULL,
  `author_id` char(36) NOT NULL,
  `favorites_count` int(11) NOT NULL DEFAULT 0,
  `tag_count` int(11) NOT NULL DEFAULT 0,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `logg` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `author_id` (`author_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`id`, `title`, `slug`, `description`, `body`, `author_id`, `favorites_count`, `tag_count`, `created`, `modified`, `logg`) VALUES
('10d6cc86-a46f-4d1f-a609-628de6bfed4e', 'How to train your dragon', 'how-to-train-your-dragon', 'Ever wonder how?', 'You have to believe', '9a0d81eb-7408-4341-ad94-93d0d510fb5f', 0, 3, '2021-08-25 19:59:37', '2021-08-25 19:59:37', NULL),
('20a82a4a-9da3-450e-a8b6-2b1fcd389593', '1629924500', '1629924500', '', '', '9a0d81eb-7408-4341-ad94-93d0d510fb5f', 0, 1, '2021-08-25 20:48:24', '2021-08-25 20:48:24', NULL),
('83d47160-0c7b-40d3-b69f-cf885761aafd', '1629922157', '1629922157', '[\"Corona Master were hit for 6 health points. \\n Additionaly, he bleeding for 2 turns.\",\"Enemy: I don\'t really want to do this.\",\"Corona Master loses 31 health points by bleeding.\",\"null were critically hit for 15 health points. Feel the pain\",\"Enemy: I didn\'t want this fight, but...\",\"null missed\",\"Enemy: You missed!\",\"Corona Master loses 31 health points by bleeding.\",\"null were hit for 8 health points\"]', '', '9a0d81eb-7408-4341-ad94-93d0d510fb5f', 0, 1, '2021-08-25 20:09:59', '2021-08-25 20:12:47', NULL),
('bfa1c7b3-230a-4b05-9d7e-d692356ef457', '1629924057', '1629924057', '', '', '9a0d81eb-7408-4341-ad94-93d0d510fb5f', 0, 1, '2021-08-25 20:44:12', '2021-08-25 20:44:12', NULL),
('d918aa2e-0723-469f-82ee-95b4336e3650', 'Payal', 'payal', '', '', '9a0d81eb-7408-4341-ad94-93d0d510fb5f', 0, 1, '2021-08-25 19:59:44', '2021-08-25 20:42:26', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `id` char(36) NOT NULL,
  `body` text DEFAULT NULL,
  `article_id` char(36) NOT NULL,
  `author_id` char(36) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `article_id` (`article_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `favorites`
--

DROP TABLE IF EXISTS `favorites`;
CREATE TABLE IF NOT EXISTS `favorites` (
  `id` char(36) NOT NULL,
  `user_id` char(36) NOT NULL,
  `article_id` char(36) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `article_id` (`article_id`,`user_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `follows`
--

DROP TABLE IF EXISTS `follows`;
CREATE TABLE IF NOT EXISTS `follows` (
  `id` char(36) NOT NULL,
  `followable_id` char(36) NOT NULL,
  `follower_id` char(36) NOT NULL,
  `blocked` tinyint(1) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `followable_id` (`followable_id`),
  KEY `follower_id` (`follower_id`,`followable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `phinxlog`
--

DROP TABLE IF EXISTS `phinxlog`;
CREATE TABLE IF NOT EXISTS `phinxlog` (
  `version` bigint(20) NOT NULL,
  `migration_name` varchar(100) DEFAULT NULL,
  `start_time` timestamp NULL DEFAULT NULL,
  `end_time` timestamp NULL DEFAULT NULL,
  `breakpoint` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `social_accounts`
--

DROP TABLE IF EXISTS `social_accounts`;
CREATE TABLE IF NOT EXISTS `social_accounts` (
  `id` char(36) NOT NULL,
  `user_id` char(36) NOT NULL,
  `provider` varchar(255) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `reference` varchar(255) NOT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `link` varchar(255) NOT NULL,
  `token` varchar(500) NOT NULL,
  `token_secret` varchar(500) DEFAULT NULL,
  `token_expires` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `data` text NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tags_tagged`
--

DROP TABLE IF EXISTS `tags_tagged`;
CREATE TABLE IF NOT EXISTS `tags_tagged` (
  `id` char(36) NOT NULL,
  `tag_id` char(36) DEFAULT NULL,
  `fk_id` char(36) DEFAULT NULL,
  `fk_table` varchar(255) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tag_id` (`tag_id`,`fk_id`,`fk_table`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tags_tags`
--

DROP TABLE IF EXISTS `tags_tags`;
CREATE TABLE IF NOT EXISTS `tags_tags` (
  `id` char(36) NOT NULL,
  `namespace` varchar(255) DEFAULT NULL,
  `slug` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  `counter` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `tag_key` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tag_key` (`tag_key`,`label`,`namespace`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` char(36) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL,
  `token_expires` datetime DEFAULT NULL,
  `api_token` varchar(255) DEFAULT NULL,
  `activation_date` datetime DEFAULT NULL,
  `tos_date` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `is_superuser` tinyint(1) NOT NULL DEFAULT 0,
  `role` varchar(255) DEFAULT 'user',
  `secret` varchar(32) DEFAULT NULL,
  `secret_verified` tinyint(1) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `first_name`, `last_name`, `token`, `token_expires`, `api_token`, `activation_date`, `tos_date`, `active`, `is_superuser`, `role`, `secret`, `secret_verified`, `bio`, `image`, `created`, `modified`) VALUES
('9a0d81eb-7408-4341-ad94-93d0d510fb5f', 'Payal Raghuwanshi', 'payal.raghuwanshi@gmail.com', '$2y$10$JgNnfxg/xHck0KTtbcmspuJgHcKLgHDn5aRccut//5C4Hz4KnJSFu', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 'user', NULL, NULL, NULL, 'abc.jpg', '2021-08-25 13:36:13', '2021-08-25 13:36:13');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `social_accounts`
--
ALTER TABLE `social_accounts`
  ADD CONSTRAINT `social_accounts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
